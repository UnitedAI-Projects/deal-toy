MantelDocs development preview, 2026-11-10

Extract this archive and run:
  python3 -m http.server 8771 --bind 127.0.0.1
Then open http://127.0.0.1:8771/?sample in a modern browser.
For a remote host, forward this port to the client first.
Do not open index.html directly using a file URL.

This is a development build, not a signed native release.
Source: https://github.com/ichen27/manteldocs
Known CAD/DWG limitations are documented in the source README.
